package Test;

import static org.junit.Assert.*;

import org.junit.Test;

public class JTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
