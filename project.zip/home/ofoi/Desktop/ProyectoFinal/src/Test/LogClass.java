package Test;

public class LogClass {

}
